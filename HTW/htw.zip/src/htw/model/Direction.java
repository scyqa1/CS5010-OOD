package htw.model;

/**
 * Enumeration for type of direction.
 */
public enum Direction {
	NORTH, SOUTH, EAST, WEST
}
