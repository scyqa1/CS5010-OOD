package htw.model;

class Edge {
	int source;
	int destination;

	Edge(int source, int destination) {
		this.source = source;
		this.destination = destination;
	}
}
