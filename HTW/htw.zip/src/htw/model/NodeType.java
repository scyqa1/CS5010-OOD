package htw.model;

/**
 * Enumeration for type of location.
 */
public enum NodeType {
	CAVE, TUNNEL
}
