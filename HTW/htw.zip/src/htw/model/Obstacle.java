package htw.model;

/**
 * Enumeration for type of difficulty.
 */
public enum Obstacle {
	WUMPUS, PIT, BAT
}
