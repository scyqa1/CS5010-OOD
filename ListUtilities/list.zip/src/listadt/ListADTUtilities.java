package listadt;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


/**
 * A utility class that implements additional functionality for abstract data types and
 * uses higher order functions.
 */
public final class ListADTUtilities<T> extends ListADTImpl<T> {

  /**
   * Creates a new instance of ListADT that contains all of the specified elements in the
   * order they appeared in elements.
   *
   * @param elements The list of elements.
   * @return A ListADT object.
   * @throws IllegalArgumentException If elements contains one or more null values.
   */
  public static <T> ListADT<T> toList(T[] elements) throws IllegalArgumentException {
    ListADT listADT = new ListADTImpl();

    for (T element : elements) {
      if (element == null) {
        throw new IllegalArgumentException();
      } else {
        listADT.addBack(element);
      }
    }

    return listADT;
  }

  /**
   * This adds the specified elements to the end of the specified list.
   *
   * @param list A listADT object list.
   * @param elements The list of elements.
   * @throws IllegalArgumentException If elements contains one more more null values.
   */
  public static <T> void addAll(ListADT<T> list, T... elements) throws IllegalArgumentException {
    for (T element : elements) {
      if (element == null) {
        throw new IllegalArgumentException();
      } else {
        list.addBack(element);
      }
    }
  }

  /**
   * This will return the number of elements in the specified list equal to the specified element.
   *
   * @param list A listADT object list.
   * @param element An element object type.
   * @return The number of elements in the list.
   */
  public static <T> int frequency(ListADT<T> list, T element) {
    int counter = 0;

    for (int i = 0; i < list.getSize(); i++) {
      if (list.get(i) == element) {
        counter += 1;
      }
    }

    return counter;
  }

  /**
   * This will return true if the two lists have no elements in common.
   *
   * @param one The first list to be used for comparison.
   * @param two The second list to be used for comparison.
   * @return True if the two lists have no elements in common.
   * @throws IllegalArgumentException If either list is null or if either list contains
   *     a null element.
   */
  public static<T> boolean disjoint(ListADT<? extends T> one, ListADT<? extends T> two) throws IllegalArgumentException {
    if (one == null || two == null) {
        throw new IllegalArgumentException();
    }
	  
    Set<T> setOne = new HashSet<>();

    boolean hasSame = false;
    int oneSize = one.getSize();
    int twoSize = two.getSize();

    T oneNode = one.get(0);
    for (int i = 0; i < oneSize; i++) {
      if (oneNode == null) {
        throw new IllegalArgumentException();
      }

      setOne.add(oneNode);
      oneNode = ((Iterator<T>) oneNode).next();
    }

    T twoNode = two.get(0);
    for (int i = 0; i < twoSize; i++) {
      if (twoNode == null) {
        throw new IllegalArgumentException();
      }
      
      if (setOne.contains(twoNode)) {
          return false;
        }
      twoNode = ((Iterator<T>) twoNode).next();
    }

    return !hasSame;
  }


  /**
   * It will return true if the two lists are equal.
   *
   * @param one The first list.
   * @param two The second list.
   * @return True if the two lists are equal.
   * @throws IllegalArgumentException If either list is null or if either list contains
   *     a null element.
   */
  public static boolean equals(ListADT<?> one, ListADT<?> two) throws IllegalArgumentException {
	String strOne = "";
	String strTwo = "";

	if (one == null || two == null) {
	  throw new IllegalArgumentException();
	}

    for (int i = 0; i < one.getSize(); i++) {
      if (one.get(i) == null) {
        throw new IllegalArgumentException();
      }

      strOne += one.get(i).toString();
    }

    for (int i = 0; i < two.getSize(); i++) {
      if (two.get(i) == null) {
        throw new IllegalArgumentException();
      }

      strTwo += two.get(i).toString();
    }


    return strOne.equals(strTwo);
  }


  /**
   * This swaps the elements at the specified position in the specified list.
   *
   * @param list The list of elements.
   * @param i Position one.
   * @param j Position two.
   * @throws IndexOutOfBoundsException If either i or j are out of range.
   */
  public void swap(ListADT<?> list, int i, int j) throws IndexOutOfBoundsException {
  if (i < 0 || j < 0 || i >= list.getSize() || j >= list.getSize()) {
      throw new IndexOutOfBoundsException();
    }

  T left = this.get(i);
  T right = this.get(j);
  this.remove(this.get(i));
  this.remove(this.get(j));

  this.add(j, left);
  this.add(i, right);

  }
}