package dungeon;

public class MedievalLevelBuilder {
	  public final int levelNumber;
	  private final Level level;

	  private int numberOfRooms;
	  private int numberOfMonsters;
	  private int numberOfTreasures;
	  private int totalRooms;

	  /**
	   * Constructor
	   */
	  public MedievalLevelBuilder(
	      int levelNumber, int numberOfRooms, int numberOfMonsters, int numberOfTreasures)
	      throws IllegalArgumentException {
	    if (levelNumber < 0 | numberOfRooms < 0 | numberOfMonsters < 0 | numberOfTreasures < 0) {
	      throw new IllegalArgumentException(" Negative values not allowed");
	    }
	    this.levelNumber = levelNumber;
	    this.numberOfRooms = numberOfRooms;
	    this.totalRooms = numberOfRooms;
	    this.numberOfMonsters = numberOfMonsters;
	    this.numberOfTreasures = numberOfTreasures;
	    level = new Level(levelNumber);
	  }

	  /**
	   * Add room
	   */
	  public MedievalLevelBuilder addRoom(String description) {
	    if (numberOfRooms == 0) {
	      throw new IllegalStateException("Room size cannot exceed number of rooms");
	    }
	    level.addRoom(description);
	    this.numberOfRooms--;
	    return this;
	  }

	  /**
	   * Add goblin monster
	   */
	  public MedievalLevelBuilder addGoblins(int index, int value) {
	    exception_MonsterAndTreasure(
	        index,
	        numberOfMonsters,
	        value);
	    
	    Monster goblin =
	        new Monster(
	            "goblin",
	            "mischievous and very unpleasant, vengeful, and greedy "
	                + "creature whose primary purpose is to cause trouble to humankind",
	            7);
	    for (int i = 0; i < value; i++) {
	      level.addMonster(index, goblin);
	      numberOfMonsters--;
	    }
	    return this;
	  }

	  /**
	   * Add orc monster
	   */
	  public MedievalLevelBuilder addOrc(int index) {
	    exception_MonsterAndTreasure(
	        index,
	        numberOfMonsters,
	        1);
	    
	    Monster orc = new Monster("orc", "brutish, aggressive, malevolent being serving evil", 20);
	    level.addMonster(index, orc);
	    numberOfMonsters--;
	    return this;
	  }

	  /**
	   * Add ogre monster
	   */
	  public MedievalLevelBuilder addOgre(int index) {
	    exception_MonsterAndTreasure(
	        index,
	        numberOfMonsters,
	        1);
	    
	    Monster ogre =
	        new Monster("ogre", "large, hideous man-like being that likes to eat humans for lunch", 50);

	    level.addMonster(index, ogre);
	    numberOfMonsters--;
	    return this;
	  }

	  /**
	   * Add human as a type of monster
	   */
	  public MedievalLevelBuilder addHuman(int index, String name, String description, int value) {
	    exception_MonsterAndTreasure(
	        index,
	        numberOfMonsters,
	        1);
	    
	    Monster human = new Monster(name, description, value);
	    level.addMonster(index, human);
	    numberOfMonsters--;
	    return this;
	  }

	  /**
	   * Add potion treasure
	   */
	  public MedievalLevelBuilder addPotion(int index) {
	    exception_MonsterAndTreasure(
	        index,
	        numberOfTreasures,
	        1);
	    
	    Treasure potion = new Treasure("a healing potion", 1);
	    level.addTreasure(index, potion);
	    numberOfTreasures--;
	    return this;
	  }

	  /**
	   * Add gold treasure
	   */
	  public MedievalLevelBuilder addGold(int index, int value) {
	    exception_MonsterAndTreasure(
	        index,
	        numberOfTreasures,
	        1);
	    
	    Treasure gold = new Treasure("pieces of gold", value);
	    level.addTreasure(index, gold);
	    numberOfTreasures--;
	    return this;
	  }

	  /**
	   * Add weapon treasure
	   */
	  public MedievalLevelBuilder addWeapon(int index, String weaponName) {
	    exception_MonsterAndTreasure(
	        index,
	        numberOfTreasures,
	        1);
	    
	    Treasure weapon = new Treasure(weaponName, 10);
	    level.addTreasure(index, weapon);
	    numberOfTreasures--;
	    return this;
	  }

	  /**
	   * Add special treasure
	   */
	  public MedievalLevelBuilder addSpecial(int index, String description, int value) {
	    exception_MonsterAndTreasure(
	        index,
	        numberOfTreasures,
	        1);
	    
	    Treasure special = new Treasure(description, value);
	    level.addTreasure(index, special);
	    numberOfTreasures--;
	    return this;
	  }

	  private void exception_MonsterAndTreasure(int index, int number, int value) {
	    if (this.numberOfRooms != 0) {
	      throw new IllegalStateException("Not enough rooms were created.");
	    }
		if (value > number) {
	      throw new IllegalStateException("maximum number of monster/treasure reached");
	    }
	    if (index < 0 || index >= totalRooms) {
	      throw new IllegalArgumentException("Room index error");
	    }
	  }

	  /**
	   * Builds the object with the specific client input.
	   *
	   * @return a level object only after it has been completely constructed
	   * @throws IllegalStateException if the level is called before completion
	   */
	  public Level build() {
	    if (numberOfRooms > 0 | numberOfMonsters > 0 | numberOfTreasures > 0) {
	      throw new IllegalStateException(
	          "Finish Creating room monsters and treasure before calling build");
	    }
	    return level;
	  }
	  
	  /*
	  public static void main(String[] args) {
		  Level level = new MedievalLevelBuilder(1, 1, 1, 1)
			            .addRoom("first room")
			            .addGoblins(0, 1)
			            .addGold(0, 1)
			            .build();
		  System.out.println(level.toString());
		  
	  }
	  */
	}