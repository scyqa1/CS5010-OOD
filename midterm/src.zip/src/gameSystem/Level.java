package gameSystem;

public enum Level {
    HARD,
    NORMAL
}
